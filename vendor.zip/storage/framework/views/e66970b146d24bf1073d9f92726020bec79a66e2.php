<div class="row">
	<input type="hidden" class="payment_row_index" value="<?php echo e($row_index, false); ?>">
	<?php
		$col_class = 'col-md-6';
		if(!empty($accounts)){
			$col_class = 'col-md-4';
		}
		$readonly = $payment_line['method'] == 'advance' ? true : false;
	?>
	<div class="<?php echo e($col_class, false); ?>">
		<div class="form-group">
			<?php echo Form::label("amount_$row_index" ,__('sale.amount') . ':*'); ?>

			<div class="input-group">
				<span class="input-group-addon">
					<i class="fas fa-money-bill-alt"></i>
				</span>
				<?php echo Form::text("payment[$row_index][amount]", number_format($payment_line['amount'], session('business.currency_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), ['class' => 'form-control payment-amount input_number', 'required', 'id' => "amount_$row_index", 'placeholder' => __('sale.amount'), 'readonly' => $readonly]); ?>

			</div>
		</div>
	</div>
	<?php if(!empty($show_date)): ?>
	<div class="<?php echo e($col_class, false); ?>">
		<div class="form-group">
			<?php echo Form::label("paid_on_$row_index" , __('lang_v1.paid_on') . ':*'); ?>

			<div class="input-group">
              <span class="input-group-addon">
                <i class="fa fa-calendar"></i>
              </span>
              <?php echo Form::text("payment[$row_index][paid_on]", isset($payment_line['paid_on']) ? \Carbon::createFromTimestamp(strtotime($payment_line['paid_on']))->format(session('business.date_format') . ' ' . 'H:i') : \Carbon::createFromTimestamp(strtotime('now'))->format(session('business.date_format') . ' ' . 'H:i'), ['class' => 'form-control paid_on', 'readonly', 'required']); ?>

            </div>
		</div>
	</div>
	<?php endif; ?>
	<div class="<?php echo e($col_class, false); ?>">
		<div class="form-group">
			<?php echo Form::label("method_$row_index" , __('lang_v1.payment_method') . ':*'); ?>

			<div class="input-group">
				<span class="input-group-addon">
					<i class="fas fa-money-bill-alt"></i>
				</span>
				<?php
					$_payment_method = empty($payment_line['method']) && array_key_exists('cash', $payment_types) ? 'cash' : $payment_line['method'];
				?>
				<?php echo Form::select("payment[$row_index][method]", $payment_types, $_payment_method, ['class' => 'form-control col-md-12 payment_types_dropdown', 'required', 'id' => !$readonly ? "method_$row_index" : "method_advance_$row_index", 'style' => 'width:100%;', 'disabled' => $readonly]); ?>


				<?php if($readonly): ?>
					<?php echo Form::hidden("payment[$row_index][method]", $payment_line['method'], ['class' => 'payment_types_dropdown', 'required', 'id' => "method_$row_index"]); ?>

				<?php endif; ?>
			</div>
		</div>
	</div>

	<?php
            $pos_settings = !empty(session()->get('business.pos_settings')) ? json_decode(session()->get('business.pos_settings'), true) : [];
            $enable_cash_denomination_for_payment_methods = !empty($pos_settings['enable_cash_denomination_for_payment_methods']) ? $pos_settings['enable_cash_denomination_for_payment_methods'] : [];
        ?>

        <?php if(!empty($pos_settings['enable_cash_denomination_on']) && ($pos_settings['enable_cash_denomination_on'] == 'all_screens' || !empty($show_in_pos)) && !empty($show_denomination)): ?>
            <input type="hidden" class="enable_cash_denomination_for_payment_methods" value="<?php echo e(json_encode($enable_cash_denomination_for_payment_methods), false); ?>">
            <div class="clearfix"></div>
            <div class="col-md-12 cash_denomination_div <?php if(!in_array($payment_line['method'], $enable_cash_denomination_for_payment_methods)): ?> hide <?php endif; ?>">
                <div class="pos-denomination-heading">
                    <span><i class="fas fa-money-bill-wave"></i></span>
                    <div><strong><?php echo app('translator')->get( 'lang_v1.cash_denominations' ); ?></strong><small>Enter the quantity received for each value</small></div>
                </div>
                  <?php if(!empty($pos_settings['cash_denominations'])): ?>
                    <?php
                        $all_denominations = \App\Utils\CashDenominationUtil::fromSettings($pos_settings);
                        $note_denominations = array_values(array_filter($all_denominations, fn($item) => $item['type'] === 'note'));
                        $coin_denominations = array_values(array_filter($all_denominations, fn($item) => $item['type'] === 'coin'));
                        $denomination_counts = [];
                        $total = 0;
                        foreach($payment_line['denominations'] ?? [] as $d) {
                            $saved_code = $d['denomination_code'] ?? null;
                            if ($saved_code) $denomination_counts[$saved_code] = $d['total_count'];
                            $total += $d['total_count'] * $d['amount'];
                        }
                    ?>
                    <div class="pos-denomination-grid">
                        <?php $__currentLoopData = ['Notes' => $note_denominations, 'Coins' => $coin_denominations]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_name => $group_denominations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <section class="pos-denomination-group">
                                <header><span><?php echo e($group_name, false); ?></span><small><?php echo app('translator')->get('lang_v1.count'); ?> &amp; <?php echo app('translator')->get('sale.subtotal'); ?></small></header>
                                <div class="pos-denomination-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $group_denominations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dnm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php
                                            $count = $denomination_counts[$dnm['code']] ?? 0;
                                            $sub_total = $count * $dnm['value'];
                                        ?>
                                        <div class="pos-denomination-row">
                                            <strong><?php echo e($dnm['label'], false); ?></strong>
                                            <span class="pos-denomination-times">×</span>
                                            <?php echo Form::number("payment[$row_index][denominations][{$dnm['code']}]", $count, ['class' => 'form-control cash_denomination input-sm', 'min' => 0, 'data-denomination' => $dnm['value'], 'data-denomination-code' => $dnm['code'], 'inputmode' => 'numeric', 'aria-label' => $group_name . ' ' . $dnm['label']]); ?>

                                            <span class="pos-denomination-equals">=</span>
                                            <span class="denomination_subtotal"><?php echo e(number_format($sub_total, session('business.currency_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p class="pos-denomination-empty">No <?php echo e(strtolower($group_name), false); ?> configured</p>
                                    <?php endif; ?>
                                </div>
                            </section>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="pos-denomination-total">
                        <span><?php echo app('translator')->get('sale.total'); ?></span><strong class="denomination_total"><?php echo e(number_format($total, session('business.currency_precision', 2), session('currency')['decimal_separator'], session('currency')['thousand_separator']), false); ?></strong>
                        <input type="hidden" class="denomination_total_amount" value="<?php echo e($total, false); ?>">
                        <input type="hidden" class="is_strict" value="<?php echo e($pos_settings['cash_denomination_strict_check'] ?? '', false); ?>">
                    </div>
                    <p class="cash_denomination_error error hide"><?php echo app('translator')->get('lang_v1.cash_denomination_error'); ?></p>
                  <?php else: ?>
                    <p class="help-block"><?php echo app('translator')->get('lang_v1.denomination_add_help_text'); ?></p>
                  <?php endif; ?>
            </div>
            <div class="clearfix"></div>
        <?php endif; ?>
	<?php if(!empty($accounts)): ?>
		<div class="<?php echo e($col_class, false); ?>">
			<div class="form-group <?php if($readonly): ?> hide <?php endif; ?>">
				<?php echo Form::label("account_$row_index" , __('lang_v1.payment_account') . ':'); ?>

				<div class="input-group">
					<span class="input-group-addon">
						<i class="fas fa-money-bill-alt"></i>
					</span>
					<?php echo Form::select("payment[$row_index][account_id]", $accounts, !empty($payment_line['account_id']) ? $payment_line['account_id'] : '' , ['class' => 'form-control select2 account-dropdown', 'id' => !$readonly ? "account_$row_index" : "account_advance_$row_index", 'style' => 'width:100%;', 'disabled' => $readonly]); ?>

				</div>
			</div>
		</div>
	<?php endif; ?>
	<div class="clearfix"></div>
		<?php echo $__env->make('sale_pos.partials.payment_type_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="col-md-12">
		<div class="form-group">
			<?php echo Form::label("note_$row_index", __('sale.payment_note') . ':'); ?>

			<?php echo Form::textarea("payment[$row_index][note]", $payment_line['note'], ['class' => 'form-control', 'rows' => 3, 'id' => "note_$row_index"]); ?>

		</div>
	</div>
</div>
<?php /**PATH C:\laragon\www\db\prakk\resources\views/sale_pos/partials/payment_row_form.blade.php ENDPATH**/ ?>