<div class="modal fade" tabindex="-1" role="dialog" id="modal_payment">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content pos-payment-modal-content">
            <div class="modal-header sticky-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <div class="pos-payment-modal-title">
                    <span><i class="fas fa-wallet"></i></span>
                    <div><h4 class="modal-title"><?php echo app('translator')->get('lang_v1.payment'); ?></h4><small>Review payment and complete this sale</small></div>
                </div>
            </div>
            <div class="modal-body">
                <div class="row pos-payment-layout">
                    <div class="col-md-12 mb-12">
                        <strong><?php echo app('translator')->get('lang_v1.advance_balance'); ?>:</strong> <span id="advance_balance_text"></span>
                        <?php echo Form::hidden('advance_balance', null, [
                            'id' => 'advance_balance',
                            'data-error-msg' => __('lang_v1.required_advance_balance_not_available'),
                        ]); ?>


                    </div>
                   
               
                    <div class="col-md-8">
                        <div class="row">
                            <div id="payment_rows_div">
                                <?php
                                    $pos_settings = !empty(session()->get('business.pos_settings')) ? json_decode(session()->get('business.pos_settings'), true) : [];
                                    $show_in_pos = '';
                                    if ($pos_settings['enable_cash_denomination_on'] == 'all_screens' || $pos_settings['enable_cash_denomination_on'] == 'pos_screen') {
                                        $show_in_pos = true;
                                    }
                                ?>
                                <?php $__currentLoopData = $payment_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($payment_line['is_return'] == 1): ?>
                                        <?php
                                            $change_return = $payment_line;
                                        ?>

                                        <?php continue; ?>
                                    <?php endif; ?>

                                    <?php echo $__env->make('sale_pos.partials.payment_row', [
                                        'removable' => !$loop->first,
                                        'row_index' => $loop->index,
                                        'payment_line' => $payment_line,
                                        'show_denomination' => true,
                                        'show_in_pos' => $show_in_pos,
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <input type="hidden" id="payment_row_index" value="<?php echo e(count($payment_lines), false); ?>">
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="tw-dw-btn tw-dw-btn-primary tw-text-white tw-dw-btn-sm tw-w-full"
                                    id="add-payment-row"><?php echo app('translator')->get('sale.add_payment_row'); ?></button>
                            </div>
                        </div>
                        <br>
                        <div class="row <?php if($change_return['amount'] == 0): ?> hide <?php endif; ?> payment_row"
                            id="change_return_payment_data">
                            <div class="col-md-12">
                                <div class="box box-solid payment_row bg-lightgray">
                                    <div class="box-body">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <?php echo Form::label('change_return_method', __('lang_v1.change_return_payment_method') . ':*'); ?>

                                                <div class="input-group">
                                                    <span class="input-group-addon">
                                                        <i class="fas fa-money-bill-alt"></i>
                                                    </span>
                                                    <?php
                                                        $_payment_method = empty($change_return['method']) && array_key_exists('cash', $payment_types) ? 'cash' : $change_return['method'];

                                                        $_payment_types = $payment_types;
                                                        if (isset($_payment_types['advance'])) {
                                                            unset($_payment_types['advance']);
                                                        }
                                                    ?>
                                                    <?php echo Form::select('payment[change_return][method]', $_payment_types, $_payment_method, [
                                                        'class' => 'form-control col-md-12 payment_types_dropdown',
                                                        'id' => 'change_return_method',
                                                        'style' => 'width:100%;',
                                                    ]); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <?php if(!empty($accounts)): ?>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <?php echo Form::label('change_return_account', __('lang_v1.change_return_payment_account') . ':'); ?>

                                                    <div class="input-group">
                                                        <span class="input-group-addon">
                                                            <i class="fas fa-money-bill-alt"></i>
                                                        </span>
                                                        <?php echo Form::select(
                                                            'payment[change_return][account_id]',
                                                            $accounts,
                                                            !empty($change_return['account_id']) ? $change_return['account_id'] : '',
                                                            ['class' => 'form-control select2', 'id' => 'change_return_account', 'style' => 'width:100%;'],
                                                        ); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="clearfix"></div>
                                        <?php echo $__env->make('sale_pos.partials.payment_type_details', [
                                            'payment_line' => $change_return,
                                            'row_index' => 'change_return',
                                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('sale_note', __('sale.sell_note') . ':'); ?>

                                    <?php echo Form::textarea('sale_note', !empty($transaction) ? $transaction->additional_notes : null, [
                                        'class' => 'form-control',
                                        'rows' => 3,
                                        'placeholder' => __('sale.sell_note'),
                                    ]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('staff_note', __('sale.staff_note') . ':'); ?>

                                    <?php echo Form::textarea('staff_note', !empty($transaction) ? $transaction->staff_note : null, [
                                        'class' => 'form-control',
                                        'rows' => 3,
                                        'placeholder' => __('sale.staff_note'),
                                    ]); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 pos-payment-summary-column">


                        <div class="box box-solid pos-payment-summary">
                            <div class="box-body">
                                <div class="col-md-12 pos-payment-stat">
                                    <strong>
                                        <?php echo app('translator')->get('lang_v1.total_items'); ?>:
                                    </strong>
                                    <br />
                                    <span class="lead text-bold total_quantity">0</span>
                                </div>

                                <div class="col-md-12 pos-payment-stat pos-payment-stat-total">
                                    <hr>
                                    <strong>
                                        <?php echo app('translator')->get('sale.total_payable'); ?>:
                                    </strong>
                                    <br />
                                    <span class="lead text-bold total_payable_span">0</span>
                                </div>

                                <div class="col-md-12 pos-payment-stat">
                                    <hr>
                                    <strong>
                                        <?php echo app('translator')->get('lang_v1.total_paying'); ?>:
                                    </strong>
                                    <br />
                                    <span class="lead text-bold total_paying">0</span>
                                    <input type="hidden" id="total_paying_input">
                                </div>

                                <div class="col-md-12 pos-payment-stat pos-payment-stat-change">
                                    <hr>
                                    <strong>
                                        <?php echo app('translator')->get('lang_v1.change_return'); ?>:
                                    </strong>
                                    <br />
                                    <span class="lead text-bold change_return_span">0</span>
                                    <?php echo Form::hidden('change_return', $change_return['amount'], [
                                        'class' => 'form-control change_return input_number',
                                        'required',
                                        'id' => 'change_return',
                                    ]); ?>

                                    <!-- <span class="lead text-bold total_quantity">0</span> -->
                                    <?php if(!empty($change_return['id'])): ?>
                                        <input type="hidden" name="change_return_id"
                                            value="<?php echo e($change_return['id'], false); ?>">
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-12 pos-payment-stat pos-payment-stat-balance">
                                    <hr>
                                    <strong>
                                        <?php echo app('translator')->get('lang_v1.balance'); ?>:
                                    </strong>
                                    <br />
                                    <span class="lead text-bold balance_due">0</span>
                                    <input type="hidden" id="in_balance_due" value=0>
                                </div>

                   

                            </div>

                            <!-- /.box-body -->
                        </div>

                  
                    </div>
                </div>
            </div>
            <div class="modal-footer pos-payment-modal-footer">
                <div class="pos-payment-footer-copy"><i class="fas fa-shield-alt"></i><span><strong>Ready to complete?</strong><small>Confirm the amount received before finalizing.</small></span></div>
                <div class="pos-payment-footer-actions">
                    <button type="button" class="tw-dw-btn tw-dw-btn-neutral tw-text-white pos-payment-close" data-dismiss="modal"><i class="fas fa-arrow-left"></i> <?php echo app('translator')->get('messages.closepayment'); ?></button>
                    <button type="submit" class="tw-dw-btn tw-dw-btn-primary tw-text-white" id="pos-save"><i class="fas fa-check-circle"></i> <?php echo app('translator')->get('sale.finalize_payment'); ?></button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Used for express checkout card transaction -->
<div class="modal fade" tabindex="-1" role="dialog" id="card_details_modal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?php echo app('translator')->get('lang_v1.card_transaction_details'); ?></h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">

                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo Form::label('card_number', __('lang_v1.card_no')); ?>

                                <?php echo Form::text('', null, [
                                    'class' => 'form-control',
                                    'placeholder' => __('lang_v1.card_no'),
                                    'id' => 'card_number',
                                    'autofocus',
                                ]); ?>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo Form::label('card_holder_name', __('lang_v1.card_holder_name')); ?>

                                <?php echo Form::text('', null, [
                                    'class' => 'form-control',
                                    'placeholder' => __('lang_v1.card_holder_name'),
                                    'id' => 'card_holder_name',
                                ]); ?>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <?php echo Form::label('card_transaction_number', __('lang_v1.card_transaction_no')); ?>

                                <?php echo Form::text('', null, [
                                    'class' => 'form-control',
                                    'placeholder' => __('lang_v1.card_transaction_no'),
                                    'id' => 'card_transaction_number',
                                ]); ?>

                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo Form::label('card_type', __('lang_v1.card_type')); ?>

                                <?php echo Form::select('', ['visa' => 'Visa', 'master' => 'MasterCard'], 'visa', [
                                    'class' => 'form-control select2',
                                    'id' => 'card_type',
                                ]); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo Form::label('card_month', __('lang_v1.month')); ?>

                                <?php echo Form::text('', null, [
                                    'class' => 'form-control',
                                    'placeholder' => __('lang_v1.month'),
                                    'id' => 'card_month',
                                ]); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo Form::label('card_year', __('lang_v1.year')); ?>

                                <?php echo Form::text('', null, ['class' => 'form-control', 'placeholder' => __('lang_v1.year'), 'id' => 'card_year']); ?>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo Form::label('card_security', __('lang_v1.security_code')); ?>

                                <?php echo Form::text('', null, [
                                    'class' => 'form-control',
                                    'placeholder' => __('lang_v1.security_code'),
                                    'id' => 'card_security',
                                ]); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer sticky-footer">
                <button type="button" class="tw-dw-btn tw-dw-btn-primary tw-text-white" id="pos-save-card"><?php echo app('translator')->get('sale.finalize_payment'); ?></button>
            </div>
        </div>
    </div>
</div>

<style>
.modal-header.sticky-header {
    position: sticky;
    top: 0;
    background-color: #fff;
    z-index: 10;
    width: 100%;
    border-bottom: 1px solid #ddd;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}



.modal-footer.sticky-footer {
    position: sticky;
    bottom: 0;
    background-color: #fff;
    z-index: 10;
    width: 100%;
    border-top: 1px solid #ddd;
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
}
.modal-body {
    overflow-y: auto;
    max-height: calc(100vh - 200px); /* Adjust height as necessary */
    padding-bottom: 60px; /* Adjust this to ensure content does not overlap the footer */
}
</style>
<?php /**PATH C:\laragon\www\db\prakk\resources\views/sale_pos/partials/payment_modal.blade.php ENDPATH**/ ?>