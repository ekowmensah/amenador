<?php
    $is_mobile = isMobile();
?>

<div class="pos-form-actions pos-v2-action-bar">
    <div class="pos-v2-action-inner">
        <div class="pos-v2-action-tools" aria-label="Sale options">
            <?php if(!Gate::check('disable_draft') || auth()->user()->can('superadmin') || auth()->user()->can('admin')): ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--quiet <?php if($pos_settings['disable_draft'] != 0): ?> hide <?php endif; ?>"
                    id="pos-draft" <?php if(!empty($only_payment)): ?> disabled <?php endif; ?>>
                    <i class="fas fa-file-alt" aria-hidden="true"></i><span><?php echo app('translator')->get('sale.draft'); ?></span>
                </button>
            <?php endif; ?>

            <?php if(!Gate::check('disable_quotation') || auth()->user()->can('superadmin') || auth()->user()->can('admin')): ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--quiet"
                    id="pos-quotation" <?php if(!empty($only_payment)): ?> disabled <?php endif; ?>>
                    <i class="fas fa-file-invoice" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.quotation'); ?></span>
                </button>
            <?php endif; ?>

            <?php if((!Gate::check('disable_suspend_sale') || auth()->user()->can('superadmin') || auth()->user()->can('admin')) && empty($pos_settings['disable_suspend'])): ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--quiet no-print pos-express-finalize"
                    data-pay_method="suspend" title="<?php echo app('translator')->get('lang_v1.tooltip_suspend'); ?>"
                    <?php if(!empty($only_payment)): ?> disabled <?php endif; ?>>
                    <i class="fas fa-pause-circle" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.suspend'); ?></span>
                </button>
            <?php endif; ?>

            <?php if((!Gate::check('disable_credit_sale') || auth()->user()->can('superadmin') || auth()->user()->can('admin')) && empty($pos_settings['disable_credit_sale_button'])): ?>
                <input type="hidden" name="is_credit_sale" value="0" id="is_credit_sale">
                <button type="button" class="pos-v2-action-button pos-v2-action-button--quiet no-print pos-express-finalize"
                    data-pay_method="credit_sale" title="<?php echo app('translator')->get('lang_v1.tooltip_credit_sale'); ?>"
                    <?php if(!empty($only_payment)): ?> disabled <?php endif; ?>>
                    <i class="fas fa-user-clock" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.credit_sale'); ?></span>
                </button>
            <?php endif; ?>

            <?php if(!Gate::check('disable_card') || auth()->user()->can('superadmin') || auth()->user()->can('admin')): ?>
                <button type="button"
                    class="pos-v2-action-button pos-v2-action-button--quiet no-print pos-express-finalize <?php if(!array_key_exists('card', $payment_types)): ?> hide <?php endif; ?>"
                    data-pay_method="card" title="<?php echo app('translator')->get('lang_v1.tooltip_express_checkout_card'); ?>">
                    <i class="fas fa-credit-card" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.express_checkout_card'); ?></span>
                </button>
            <?php endif; ?>

            <?php if(!isset($pos_settings['hide_recent_trans']) || $pos_settings['hide_recent_trans'] == 0): ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--quiet"
                    data-toggle="modal" data-target="#recent_transactions_modal" id="recent-transactions">
                    <i class="fas fa-clock" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.recent_transactions'); ?></span>
                </button>
            <?php endif; ?>
        </div>

        <div class="pos-v2-payment-cluster">
        <div class="pos-v2-action-summary">
            <span class="pos-v2-action-summary-label"><?php echo app('translator')->get('sale.total_payable'); ?></span>
            <input type="hidden" name="final_total" id="final_total_input" value="0.00">
            <span id="total_payable" class="number pos-v2-action-total" aria-live="polite">0.00</span>
        </div>

        <div class="pos-v2-action-primary" aria-label="Payment options">
            <?php if(!Gate::check('disable_express_checkout') || auth()->user()->can('superadmin') || auth()->user()->can('admin')): ?>
                <button type="button"
                    class="pos-v2-action-button pos-v2-action-button--cash no-print pos-express-finalize <?php if($pos_settings['disable_express_checkout'] != 0 || !array_key_exists('cash', $payment_types)): ?> hide <?php endif; ?>"
                    data-pay_method="cash" title="<?php echo app('translator')->get('tooltip.express_checkout'); ?>">
                    <i class="fas fa-money-bill-wave" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.express_checkout_cash'); ?></span>
                </button>
            <?php endif; ?>

            <?php if(!Gate::check('disable_pay_checkout') || auth()->user()->can('superadmin') || auth()->user()->can('admin')): ?>
                <button type="button"
                    class="pos-v2-action-button pos-v2-action-button--checkout no-print <?php if($pos_settings['disable_pay_checkout'] != 0): ?> hide <?php endif; ?>"
                    id="pos-finalize" title="<?php echo app('translator')->get('lang_v1.tooltip_checkout_multi_pay'); ?>">
                    <i class="fas fa-arrow-right" aria-hidden="true"></i><span><?php echo app('translator')->get('lang_v1.checkout_multi_pay'); ?></span>
                </button>
            <?php endif; ?>

            <?php if(empty($edit)): ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--danger" id="pos-cancel">
                    <i class="fas fa-times" aria-hidden="true"></i><span><?php echo app('translator')->get('sale.cancel'); ?></span>
                </button>
            <?php else: ?>
                <button type="button" class="pos-v2-action-button pos-v2-action-button--danger hide" id="pos-delete"
                    <?php if(!empty($only_payment)): ?> disabled <?php endif; ?>>
                    <i class="fas fa-trash-alt" aria-hidden="true"></i><span><?php echo app('translator')->get('messages.delete'); ?></span>
                </button>
            <?php endif; ?>

            <span class="curr_datetime pos-v2-action-clock" id="vintageClock" aria-label="Current time"></span>
        </div>
        </div>
    </div>
</div>

<?php if(isset($transaction)): ?>
    <?php echo $__env->make('sale_pos.partials.edit_discount_modal', [
        'sales_discount' => $transaction->discount_amount,
        'discount_type' => $transaction->discount_type,
        'rp_redeemed' => $transaction->rp_redeemed,
        'rp_redeemed_amount' => $transaction->rp_redeemed_amount,
        'max_available' => !empty($redeem_details['points']) ? $redeem_details['points'] : 0,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('sale_pos.partials.edit_discount_modal', [
        'sales_discount' => $business_details->default_sales_discount,
        'discount_type' => 'percentage',
        'rp_redeemed' => 0,
        'rp_redeemed_amount' => 0,
        'max_available' => 0,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(isset($transaction)): ?>
    <?php echo $__env->make('sale_pos.partials.edit_order_tax_modal', ['selected_tax' => $transaction->tax_id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('sale_pos.partials.edit_order_tax_modal', [
        'selected_tax' => $business_details->default_sales_tax,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->make('sale_pos.partials.edit_shipping_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    (function () {
        function updatePosClock() {
            var clock = document.getElementById('vintageClock');
            if (!clock) {
                return;
            }

            clock.textContent = new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        updatePosClock();
        window.setInterval(updatePosClock, 1000);
    })();
</script>
<?php /**PATH C:\laragon\www\db\prakk\resources\views/sale_pos/partials/pos_form_actions.blade.php ENDPATH**/ ?>