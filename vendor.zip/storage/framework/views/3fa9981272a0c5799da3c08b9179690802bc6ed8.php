<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<?php
		$defaultProductImage = asset('/img/default.png') . '?v=' . filemtime(public_path('img/default.png'));
		$productImage = null;
		if (count($product->media) > 0) {
			$productImage = $product->media->first()->display_url;
		} elseif (!empty($product->product_image)) {
			$productImage = asset('/uploads/img/' . rawurlencode($product->product_image));
		}
	?>
	<div class="col-md-3 col-xs-4 product_list no-print" data-stock-status="<?php if($product->enable_stock && $product->qty_available <= 0): ?> out_of_stock <?php elseif($product->enable_stock && $product->qty_available <= ($product->alert_quantity ?? 5)): ?> low_stock <?php else: ?> in_stock <?php endif; ?>">
		<div class="product_box pos-modern-product"
			data-variation_id="<?php echo e($product->id, false); ?>"
			data-product_name="<?php echo e($product->name, false); ?>"
			data-variation_name="<?php echo e($product->variation, false); ?>"
			data-sub_sku="<?php echo e($product->sub_sku, false); ?>"
			data-selling_price="<?php echo e($product->selling_price, false); ?>"
			data-qty_available="<?php echo e($product->qty_available, false); ?>"
			data-enable_stock="<?php echo e($product->enable_stock, false); ?>"
			data-unit="<?php echo e($product->unit, false); ?>"
			title="<?php echo e($product->name, false); ?> <?php if($product->type == 'variable'): ?>- <?php echo e($product->variation, false); ?> <?php endif; ?> <?php echo e('(' . $product->sub_sku . ')', false); ?> <?php if(!empty($show_prices)): ?> <?php echo app('translator')->get('lang_v1.default'); ?> - <?php 
            $formated_number = "";
            if (session("business.currency_symbol_placement") == "before") {
                $formated_number .= session("currency")["symbol"] . " ";
            } 
            $formated_number .= number_format((float) $product->selling_price, session("business.currency_precision", 2) , session("currency")["decimal_separator"], session("currency")["thousand_separator"]);

            if (session("business.currency_symbol_placement") == "after") {
                $formated_number .= " " . session("currency")["symbol"];
            }
            echo $formated_number; ?> <?php $__currentLoopData = $product->group_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(array_key_exists($group_price->price_group_id, $allowed_group_prices)): ?> <?php echo e($allowed_group_prices[$group_price->price_group_id], false); ?> - <?php 
            $formated_number = "";
            if (session("business.currency_symbol_placement") == "before") {
                $formated_number .= session("currency")["symbol"] . " ";
            } 
            $formated_number .= number_format((float) $group_price->price_inc_tax, session("business.currency_precision", 2) , session("currency")["decimal_separator"], session("currency")["thousand_separator"]);

            if (session("business.currency_symbol_placement") == "after") {
                $formated_number .= " " . session("currency")["symbol"];
            }
            echo $formated_number; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>">
		<span class="pos-product-stock <?php if($product->qty_available <= 0): ?> is-empty <?php elseif($product->enable_stock && $product->qty_available <= ($product->alert_quantity ?? 5)): ?> is-low <?php endif; ?>">
			<?php if($product->qty_available > 0): ?> <?php echo e(number_format($product->qty_available, 2), false); ?> in stock <?php else: ?> Out of stock <?php endif; ?>
		</span>

		<div class="image-container" 
			style="background-image: <?php if($productImage): ?> url('<?php echo e($productImage, false); ?>'), <?php endif; ?> url('<?php echo e($defaultProductImage, false); ?>');
			background-repeat: no-repeat; background-position: center;
			background-size: contain;">
			
		</div>

		<div class="text_div pos-product-copy">
			<strong class="pos-product-name"><?php echo e($product->name, false); ?>

			<?php if($product->type == 'variable'): ?>
				- <?php echo e($product->variation, false); ?>

			<?php endif; ?>
			</strong>
			<div class="pos-product-meta">
				<span class="pos-product-sku">SKU: <?php echo e($product->sub_sku, false); ?></span>
				<span class="pos-product-price"><?php 
            $formated_number = "";
            if (session("business.currency_symbol_placement") == "before") {
                $formated_number .= session("currency")["symbol"] . " ";
            } 
            $formated_number .= number_format((float) $product->selling_price, session("business.currency_precision", 2) , session("currency")["decimal_separator"], session("currency")["thousand_separator"]);

            if (session("business.currency_symbol_placement") == "after") {
                $formated_number .= " " . session("currency")["symbol"];
            }
            echo $formated_number; ?></span>
			</div>
		</div>
			
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	<input type="hidden" id="no_products_found">
	<div class="col-md-12 pos-product-empty">
		<i class="fas fa-box-open"></i>
		<h4><?php echo app('translator')->get('lang_v1.no_products_to_display'); ?></h4>
		<p>Try another category, brand or search term.</p>
	</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\db\prakk\resources\views/sale_pos/partials/product_list.blade.php ENDPATH**/ ?>